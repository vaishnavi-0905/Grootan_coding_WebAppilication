# Grootan_Coding_WebApplication
Created for webapplication development

This project is developed to design webapplication to upload csv file of more than 1Lakh records with header values and tried to hash the password field. But, hashing the password field is having challenges in the given span of time.

Installed mongo and nodejs in local.

Launch the application by using this URL http://localhost:3000/

Then upload the csv file with required records

In windows powershell, install and start the npm server and will display the progress of the upload of data in mongo db.
npm install
npm start

once completed, application will give the complete message in UI and window powershell will display the count of the records inserted in db.

In mongo db, we can check the records inserted.

Challenges: Faced challenges in hashing the password and it is taking more time while trying to hash the password.
